## Simple Functions

Check out the [function syntax](http://kotlinlang.org/docs/reference/basic-syntax.html#defining-functions)
and change the code to make the function `start` return the string `"OK"`.

In the Kotlin Koans tasks the function `TODO()` will throw an exception.
To complete Kotlin Koans you need to replace this function invocation with meaningful code according to the problem.
