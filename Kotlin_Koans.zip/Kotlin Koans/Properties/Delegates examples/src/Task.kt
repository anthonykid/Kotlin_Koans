import com.sun.org.omg.CORBA.Initializer

class LazyProperty(val initializer: () -> Int) {
    val lazyValue: Int by lazy(initializer)
}

