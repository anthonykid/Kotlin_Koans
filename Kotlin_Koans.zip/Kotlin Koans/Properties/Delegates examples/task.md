## Delegates example

Learn about [delegated properties](http://kotlinlang.org/docs/reference/delegated-properties.html)
and make the property lazy using delegates.
