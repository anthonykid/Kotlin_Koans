## The function apply

The previous examples can be rewritten using the library function
[`apply`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/apply.html).
Write your own implementation of this function named 'myApply'.

Learn about the other [scope functions](https://kotlinlang.org/docs/reference/scope-functions.html)
and how to use them.
