## Builders implementation

Complete the implementation of a simplified DSL for HTML.
Implement 'tr' and 'td' functions.

Learn more about [type-safe builders](https://kotlinlang.org/docs/reference/type-safe-builders.html#type-safe-builders).
