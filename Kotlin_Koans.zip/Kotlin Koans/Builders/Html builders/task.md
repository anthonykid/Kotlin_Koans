## HTML builder

_1._ Fill the table with proper values from the product list.
The products are declared in `data.kt`.

_2._ Color the table like a chess board.
Use the `getTitleColor()` and `getCellColor()` functions.
Pass a color as an argument to the functions `tr`, `td`.

Run the main function defined in the file `demo.kt` to see the rendered table.
