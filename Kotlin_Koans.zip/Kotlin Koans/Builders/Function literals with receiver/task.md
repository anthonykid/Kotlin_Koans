## Function literals with receiver

Learn about [function literals with receiver](https://kotlinlang.org/docs/reference/lambdas.html#function-literals-with-receiver).

You can declare `isEven` and `isOdd` as values, that can be called as extension functions.
Complete the declarations in the code.
