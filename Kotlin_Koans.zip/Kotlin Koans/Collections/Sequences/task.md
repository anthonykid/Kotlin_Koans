## Sequences

Learn about [sequences](https://kotlinlang.org/docs/reference/sequences.html),
they allow you to perform operations lazily rather than eagerly.
Copy the implementation from the previous task and modify it in a way
that the operations on sequences are used. 
